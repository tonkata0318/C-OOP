﻿namespace Restaurant
{
    public class HotBeverage : Beverage
    {
        public HotBeverage(string name, decimal price, double millimetres)
            : base(name, price, millimetres)
        {
        }
    }
}
