﻿namespace BirthdayCelebrations;

public interface INameable
{
    string Name { get; }
}